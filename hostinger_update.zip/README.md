# HADI DIGITAL - Single-Tenant Account Distribution Portal & Khata Ledger
### Hostinger Deployment & Live Update Guide (PHP + SQLite)

**Target Subdomain:** `asim.eztoolbox.xyz`  
**Target Directory:** `public_html/asim/`

---

### 1. Credentials & Login Details
- **Admin Login:**
  - Username: `Hadi`
  - Password: `91199119`
- **Client Login:**
  - Username: `rana asim`
  - Password: `rana@123`
- **Secure Extraction PIN:**
  - `1234`
- **Default Rate:** `18 PKR / mail` (Customizable per order / delivery batch)

---

### 2. Files List
```
public_html/asim/
├── .htaccess             # Apache protection, disables directory listing, blocks direct .sqlite access
├── config.php            # Master credentials, PIN, managed domains, SQLite path
├── db.php                # PDO SQLite connector with auto-migration for payments & replacements
├── auth.php              # Session hardening, CSRF tokens, role-based authorization
├── api.php               # Unified API router with financial ledger, orders, payments, replacements & search
├── index.php             # Modern single-page portal with Khata ledger, payments hub & single mail finder
└── db/
    └── .htaccess         # "Require all denied" to prevent direct browser downloads
```

---

### 3. Kaam Kaise Live Karein (Live Update Instructions):

Agar aapki website already `asim.eztoolbox.xyz` par chal rahi hai aur database mein already records hain:

#### Option A: Direct File Upload (Recommended & 100% Safe)
1. Hostinger hPanel me **File Manager** kholein:
   - `public_html/asim/` folder me jayein.
2. Sirf ye 3 files upload / overwrite kar dein:
   - `index.php`
   - `api.php`
   - `db.php`
3. **Mera Purana Record Kharaab To Nahi Hoga?**
   - **Bilkul Nahi!** `db.php` me auto-migration code likha hua hai. Jaise hi page load hoga, SQLite database automatically `payments` aur `replacements` tables add kar lega aur purana data 100% mehfooz rahega.
4. Browser me `https://asim.eztoolbox.xyz` open karein aur `Ctrl + Shift + R` (Hard Refresh) dabayein taake new JavaScript load ho jaye.

#### Option B: Full ZIP Upload
1. `hadi_digital_hostinger.zip` ko `public_html/asim/` me upload karein.
2. File ko **Extract** karein.
3. *(Note: Agar aapka purana `db/vault_data.sqlite` mojud hai to usko delete na karein; naye code se purana data safe rahega).*

---

### 4. New Portal Features & Usage Guide:

1. **Old WhatsApp Orders Ingestion (Manual Entry):**
   - Admin Panel me **"Record / Ingest Order"** button dabayein.
   - Order Number (e.g. `Order #1` ya apna custom number), Date, Rate (Default 18 PKR ya custom), aur WhatsApp CSV paste karein ya file select karein.
   - Save karte hi yeh order history aur Khata me exact first day ki tarah add ho jayega!
   - Kisi bhi order ko baad me **Edit** ya **Delete** bhi kar sakte hain.

2. **Payments (Wasooli) Tracker:**
   - Client ne jab jab payment ki (Bank Transfer, EasyPaisa, Cash, etc.), Admin panel me **"Record Payment"** dabayein.
   - Amount, Date aur Reference Note daal kar save karein. Total Received barh jayega aur Pending Balance foran kam ho jayega.

3. **Replacements Auto-Deduction:**
   - Faulty mails ko direct **"Add Faulty Replacements"** me paste karein.
   - System un mails ko replaced mark karega, total sale quantity se minus karega aur unki amount total bill se deduct (kam) kar dega!
   - Client portal par instruction likhne ki zarorat nahi hai; client ko bahir se total deducted count aur amount dikhegi aur button daba kar list dekh sakega.

4. **Single Mail Credential Finder:**
   - Admin aur Client dono ke dashboard par **"Mail Credential Finder"** box hai.
   - Kisi bhi email ko paste karke search karein; uska Password, Recovery, Domain, Order Number aur date foran mil jayegi, plus single-click copy button bhi hai!

5. **Download Account Statement:**
   - Client aur Admin dono **"Download Statement (CSV)"** button daba kar mukammal financial ledger download kar sakte hain.

