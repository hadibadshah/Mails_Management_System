# HADI DIGITAL - Single-Tenant Account Distribution Portal & Khata Ledger
### Hostinger Deployment & Live Update Guide (PHP + SQLite)

**Target Subdomain:** `asim.eztoolbox.xyz`  
**Target Directory:** `public_html/asim/`

---

### 1. Credentials & Login Details
- **Admin Login:**
  - Username: `Hadi`
  - Password: `91199119`
- **Client Login:**
  - Username: `rana asim`
  - Password: `rana@123`
- **Secure Extraction PIN:**
  - `1234`
- **Default Rate:** `18 PKR / mail` (Customizable per order / delivery batch)

---

### 2. Files List
```
public_html/asim/
├── .htaccess             # Apache protection, disables directory listing, blocks direct .sqlite access
├── config.php            # Master credentials, PIN, managed domains, SQLite path
├── db.php                # PDO SQLite connector with auto-migration for payments & replacements
├── auth.php              # Session hardening, CSRF tokens, role-based authorization
├── api.php               # Unified API router with financial ledger, orders, payments, replacements & search
├── index.php             # Modern single-page portal with Khata ledger, payments hub & single mail finder
└── db/
    └── .htaccess         # "Require all denied" to prevent direct browser downloads
```

---

### 3. Kaam Kaise Live Karein (Hostinger Par Files Replace Karne Ka Tareeqa):

Agar aapki website already `asim.eztoolbox.xyz` par chal rahi hai:

#### Tareeqa 1: Sirf Update Hui Files Upload Karein (Sab Se Aasan & 100% Safe)
1. Hostinger hPanel login karein aur **File Manager** kholein.
2. `public_html/asim/` folder me jayein.
3. Sirf ye 3 files upload / overwrite kar dein:
   - `index.php` (Naya maintenance switch, test client view aur updated UI)
   - `api.php` (Maintenance APIs, extraction clearance aur admin bypass)
   - `db.php` (Auto-created `settings` table)
4. **Mera Purana Database Data Safe Rahega?**
   - **Ji Haan 100%!** `db.php` purane `db/vault_data.sqlite` ko hath nahi lagata, sirf auto-migration se naya `settings` table bana deta hai agar na ho. Aapka pehla tamam stock, orders, wasooli (payments) aur replacements bilkul safe rehte hain.
5. Browser me `https://asim.eztoolbox.xyz` open karein aur `Ctrl + Shift + R` (Hard Refresh) dabayein.

#### Tareeqa 2: Full ZIP Upload
1. Agar tamam files ek sath update karni hon, to `public_html/asim/` me zip upload karke extract kar lein.
2. *(Zaroori: `db/vault_data.sqlite` ko delete na karein taake aapka stock aur khata barqarar rahe).*

---

### 4. Naya Feature: Client Portal Maintenance Mode & Admin Live Testing:

Jab aap website par naya stock daal rahe hon ya settings update kar rahe hon, to aap chahte hain ke **Client confuse na ho aur portal uske liye "Under Maintenance" ho jaye, jabke AAP (Admin) client side ko live test bhi kar sakein**:

1. **Maintenance Mode Activate Karna:**
   - Admin Panel me login karein (`Hadi` / `91199119`).
   - Top right par **"Client: LIVE"** button par click karein.
   - Switch ko ON karein aur chahein to custom notice message likhein (e.g. "Stock updates in progress, 15 minute me wapis aayenge").
   - **Save Settings** click karein.
   - Foran top par Amber alert banner aa jayega aur button **"Client: MAINTENANCE"** ho jayega.

2. **Client Ko Kya Nazar Aayega?**
   - Rana Asim jab bhi login karega ya refresh karega, usko professional **"Portal Under Maintenance"** screen nazar aayegi.
   - Uska account aur data bilkul safe rahega, aur wo bar bar refresh karke pareshan nahi hoga.

3. **Admin Test Client View (Aap Kaise Test Kareinge?):**
   - Admin panel par **"Test Client View"** button dabayein.
   - Aap foran Client Portal me chale jayenge!
   - Wahan top par Indigo banner hoga jo batayega ke aap **Admin Live Preview Mode** me hain.
   - Aap client ki tarah live extractions, single mail search, aur khata ledger test kar sakte hain.
   - Jab testing mukammal ho jaye:
     - Banner par **"Back to Admin Panel"** dabayein.
     - Ya wahin se direct **"Switch to LIVE"** dabayein jab aap client ke liye website open karna chahein.

---

### 5. Other Key Features:

1. **Old WhatsApp Orders Ingestion (Manual Entry):**
   - Admin Panel me **"+ Ingest Order"** button dabayein.
   - Order Number, Date, Rate (18 PKR default ya custom), aur WhatsApp CSV paste karein.
   - Save karte hi yeh order history aur Khata me add ho jayega.

2. **Payments (Wasooli) Tracker:**
   - Admin panel me **"+ Record Payment"** dabayein.
   - Amount, Date aur Reference Note daal kar save karein. Total Received barh jayega aur Pending Balance foran kam ho jayega.

3. **Replacements Auto-Deduction:**
   - Faulty mails ko direct **"+ Add Replacements"** me paste karein.
   - System un mails ko replaced mark karega, total sale quantity se minus karega aur unki amount total bill se deduct kar dega.

4. **Single Mail Credential Finder:**
   - Admin aur Client dono ke dashboard par **"Mail Credential Finder"** box hai.
   - Kisi bhi email ko paste karke search karein; uska Password, Recovery, Domain, Order Number aur date foran mil jayegi, plus copy button bhi hai.

5. **Download Account Statement:**
   - Client aur Admin dono **"Statement"** button daba kar mukammal financial ledger download kar sakte hain.

