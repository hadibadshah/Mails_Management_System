<?php
/**
 * Single-Tenant Email Accounts Vault - High-Tech Cyber Portal
 * Clean ASCII / Standard UTF-8 - Hostinger Production Ready
 */

declare(strict_types=1);

define('VAULT_APP', true);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

Auth::initSession();
$currentUser = Auth::user();
$csrfToken = Auth::getCsrfToken();
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hadi Digital | Email Account Distribution Portal</title>
    
    <!-- Google Fonts: Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    
    <!-- Tailwind CSS (via CDN) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Poppins', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    },
                    colors: {
                        vault: {
                            bg: '#020617',
                            card: 'rgba(15, 23, 42, 0.75)',
                            border: 'rgba(51, 65, 85, 0.6)',
                            cyan: '#06b6d4',
                            glow: '#0ea5e9',
                            emerald: '#10b981',
                            amber: '#f59e0b',
                            rose: '#f43f5e'
                        }
                    },
                    boxShadow: {
                        'cyber-cyan': '0 0 25px -5px rgba(6, 182, 212, 0.3)',
                        'cyber-emerald': '0 0 25px -5px rgba(16, 185, 129, 0.3)',
                        'cyber-glow': '0 0 35px -5px rgba(14, 165, 233, 0.25)'
                    }
                }
            }
        };
    </script>
    
    <!-- Animate.css for smooth animations -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    
    <!-- SweetAlert2 (Dark Cyber Theme) -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- particles.js -->
    <script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>

    <style>
        body {
            background-color: #020617;
            font-family: 'Poppins', sans-serif;
            color: #e2e8f0;
            overflow-x: hidden;
        }

        #particles-js {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
        }

        .glass-panel {
            background: rgba(15, 23, 42, 0.78);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(51, 65, 85, 0.65);
            box-shadow: 0 10px 35px -10px rgba(0, 0, 0, 0.5);
        }

        .glass-panel-glow {
            background: rgba(15, 23, 42, 0.82);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(6, 182, 212, 0.35);
            box-shadow: 0 0 30px -5px rgba(6, 182, 212, 0.15);
        }

        .custom-scroll::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        .custom-scroll::-webkit-scrollbar-track {
            background: rgba(15, 23, 42, 0.6);
        }
        .custom-scroll::-webkit-scrollbar-thumb {
            background: #334155;
            border-radius: 9999px;
        }
        .custom-scroll::-webkit-scrollbar-thumb:hover {
            background: #06b6d4;
        }

        /* SweetAlert2 Cyber Vault Custom Skin */
        .swal2-popup.cyber-swal {
            background: #0b1329 !important;
            border: 1px solid rgba(6, 182, 212, 0.4) !important;
            border-radius: 1rem !important;
            color: #f1f5f9 !important;
            box-shadow: 0 0 40px rgba(6, 182, 212, 0.25) !important;
            font-family: 'Poppins', sans-serif !important;
        }
        .cyber-swal .swal2-title {
            color: #38bdf8 !important;
            font-weight: 700 !important;
        }
        .cyber-swal .swal2-html-container {
            color: #cbd5e1 !important;
        }
        .cyber-swal .swal2-input {
            background: #020617 !important;
            border: 1px solid #334155 !important;
            color: #38bdf8 !important;
            font-family: 'JetBrains Mono', monospace !important;
            letter-spacing: 0.25em !important;
            font-size: 1.5rem !important;
            text-align: center !important;
            border-radius: 0.5rem !important;
        }
        .cyber-swal .swal2-input:focus {
            border-color: #06b6d4 !important;
            box-shadow: 0 0 15px rgba(6, 182, 212, 0.4) !important;
        }
    </style>
</head>
<body class="relative min-h-screen selection:bg-cyan-500/30 selection:text-cyan-200">

    <!-- Interactive Particle Background -->
    <div id="particles-js"></div>

    <!-- Application Shell -->
    <div class="relative z-10 min-h-screen flex flex-col justify-between">
        
        <!-- Navigation Header -->
        <header class="sticky top-0 z-50 glass-panel border-b border-slate-800/80 px-4 lg:px-8 py-3.5 transition-all">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <!-- Logo & Brand -->
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-sky-500 to-indigo-600 flex items-center justify-center shadow-cyber-cyan">
                        <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                        </svg>
                    </div>
                    <div>
                        <div class="flex items-center space-x-2">
                            <h1 class="text-lg font-bold tracking-wider text-white">HADI <span class="text-cyan-400">DIGITAL</span></h1>
                        </div>
                        <p class="text-xs text-slate-400 font-mono tracking-tight">Email Account Distribution Portal</p>
                    </div>
                </div>

                <!-- Session User Controls -->
                <div class="flex items-center space-x-3">
                    <div id="header-auth-badge" class="hidden items-center space-x-3">
                        <div class="text-right hidden sm:block">
                            <div id="header-user-name" class="text-sm font-semibold text-slate-200">User</div>
                            <div id="header-user-role" class="text-[10px] uppercase font-mono text-cyan-400 tracking-wider">Role</div>
                        </div>
                        <button onclick="VaultApp.logout()" class="px-3.5 py-1.5 rounded-lg text-xs font-semibold text-rose-300 bg-rose-500/10 border border-rose-500/20 hover:bg-rose-500/20 transition-all flex items-center space-x-1.5">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                            </svg>
                            <span>Logout</span>
                        </button>
                    </div>

                    <div id="header-login-badge" class="flex items-center">
                        <span class="text-xs font-mono text-slate-400 flex items-center space-x-2">
                            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                            <span>System Online</span>
                        </span>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Workspace View Container -->
        <main class="flex-grow max-w-7xl w-full mx-auto px-4 lg:px-8 py-8">
            
            <!-- VIEW 1: AUTHENTICATION KEYCARD LOGIN -->
            <section id="view-login" class="max-w-md mx-auto my-12 animate__animated animate__fadeIn">
                <div class="glass-panel-glow rounded-2xl p-8 relative overflow-hidden">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none"></div>
                    <div class="absolute bottom-0 left-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none"></div>

                    <div class="text-center mb-8">
                        <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-slate-800/80 border border-cyan-500/40 text-cyan-400 mb-4 shadow-cyber-cyan">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/>
                            </svg>
                        </div>
                        <h2 class="text-2xl font-bold text-white tracking-tight">Security Clearance</h2>
                        <p class="text-xs text-slate-400 mt-1">Authenticate to access cryptographic account vault</p>
                    </div>

                    <form id="form-login" onsubmit="VaultApp.handleLogin(event)" class="space-y-4">
                        <div>
                            <label class="block text-xs font-mono font-medium text-slate-300 mb-1 uppercase tracking-wider">Access Identifier (Username)</label>
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                                </span>
                                <input type="text" id="login-username" required class="w-full pl-10 pr-4 py-2.5 bg-slate-950/80 border border-slate-700/80 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 text-sm font-sans transition-all" placeholder="Enter username">
                            </div>
                        </div>

                        <div>
                            <label class="block text-xs font-mono font-medium text-slate-300 mb-1 uppercase tracking-wider">Passcode Key</label>
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                                </span>
                                <input type="password" id="login-password" required class="w-full pl-10 pr-4 py-2.5 bg-slate-950/80 border border-slate-700/80 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 text-sm font-sans transition-all" placeholder="Enter password">
                            </div>
                        </div>

                        <button type="submit" id="btn-login-submit" class="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 via-sky-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-semibold text-sm tracking-wide shadow-cyber-cyan hover:shadow-cyan-500/50 transition-all flex items-center justify-center space-x-2">
                            <span>VERIFY & ENTER VAULT</span>
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                        </button>
                    </form>
                </div>
            </section>


            <!-- VIEW 2: CLIENT PORTAL (EXTRACTION & REPLACEMENT & STOCK) -->
            <section id="view-client" class="hidden space-y-8 animate__animated animate__fadeIn">
                <!-- Welcome Banner -->
                <div class="glass-panel rounded-2xl p-6 relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <div class="flex items-center space-x-2 mb-1">
                            <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                            <span class="text-xs font-mono uppercase tracking-widest text-emerald-400">Client Distribution Terminal</span>
                        </div>
                        <h2 class="text-2xl font-bold text-white tracking-tight">Active Stock & Extraction Hub</h2>
                        <p class="text-xs text-slate-400 mt-0.5">Secure, authenticated email account extraction with atomic database locking.</p>
                    </div>
                    <div class="flex items-center space-x-3">
                        <button onclick="VaultApp.refreshStock()" class="px-4 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-xs font-mono text-cyan-300 flex items-center space-x-2 transition-all">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
                            <span>Live Sync</span>
                        </button>
                    </div>
                </div>

                <!-- REAL-TIME STOCK METRICS (Specified for bsis5.ch and adlover.site) -->
                <div>
                    <h3 class="text-xs font-mono text-slate-400 uppercase tracking-widest mb-3 flex items-center space-x-2">
                        <span>Real-Time Inventory Status</span>
                        <span class="h-px flex-grow bg-slate-800"></span>
                    </h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6" id="client-stock-grid">
                        <!-- Stock cards injected dynamically -->
                    </div>
                </div>

                <!-- DUAL OPERATIONAL TERMINALS: EXTRACTION + REPLACEMENT -->
                <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
                    
                    <!-- TERMINAL A: EXTRACTION FORM (7 cols) -->
                    <div class="lg:col-span-7 glass-panel-glow rounded-2xl p-6 lg:p-8 relative">
                        <div class="flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
                            <div>
                                <h3 class="text-lg font-bold text-white flex items-center space-x-2">
                                    <svg class="w-5 h-5 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                                    <span>Account Extraction Engine</span>
                                </h3>
                                <p class="text-xs text-slate-400 mt-1">Select domain, specify quantity, and unlock with PIN.</p>
                            </div>
                            <span class="px-2.5 py-1 rounded-md text-[10px] font-mono uppercase bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">PIN Protected</span>
                        </div>

                        <form id="form-extract" onsubmit="VaultApp.handleExtractSubmit(event)" class="space-y-5">
                            <!-- Domain Selection -->
                            <div>
                                <label class="block text-xs font-mono text-slate-300 mb-2 uppercase tracking-wider">Select Managed Domain</label>
                                <div class="grid grid-cols-2 gap-3" id="extract-domain-options">
                                    <!-- Populated dynamically -->
                                </div>
                            </div>

                            <!-- Quantity Input + Quick Selector Chips -->
                            <div>
                                <div class="flex items-center justify-between mb-2">
                                    <label class="text-xs font-mono text-slate-300 uppercase tracking-wider">Extraction Quantity</label>
                                    <span id="extract-stock-hint" class="text-xs font-mono text-cyan-400">Available: --</span>
                                </div>
                                <div class="relative">
                                    <input type="number" id="extract-quantity" min="1" required class="w-full px-4 py-2.5 bg-slate-950/80 border border-slate-700 rounded-xl text-white font-mono text-lg focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all" placeholder="e.g. 10">
                                </div>
                                <div class="flex items-center space-x-2 mt-2.5">
                                    <button type="button" onclick="VaultApp.setExtractQty(5)" class="px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-cyan-950/50 border border-slate-700/80 text-xs font-mono text-slate-300 hover:text-cyan-300 transition-all">+5</button>
                                    <button type="button" onclick="VaultApp.setExtractQty(10)" class="px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-cyan-950/50 border border-slate-700/80 text-xs font-mono text-slate-300 hover:text-cyan-300 transition-all">+10</button>
                                    <button type="button" onclick="VaultApp.setExtractQty(25)" class="px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-cyan-950/50 border border-slate-700/80 text-xs font-mono text-slate-300 hover:text-cyan-300 transition-all">+25</button>
                                </div>
                            </div>

                            <!-- Format Selection -->
                            <div>
                                <label class="block text-xs font-mono text-slate-300 mb-2 uppercase tracking-wider">Export Format</label>
                                <div class="grid grid-cols-2 gap-3">
                                    <label class="cursor-pointer">
                                        <input type="radio" name="export-format" value="csv" checked class="peer sr-only">
                                        <div class="p-3.5 rounded-xl border border-slate-700/80 bg-slate-950/40 peer-checked:border-cyan-400 peer-checked:bg-cyan-950/20 transition-all flex items-center justify-between">
                                            <div>
                                                <div class="text-sm font-semibold text-white">CSV File</div>
                                                <div class="text-[11px] text-slate-400 font-mono">Comma Separated</div>
                                            </div>
                                            <span class="text-xs font-mono text-cyan-400 font-bold">.csv</span>
                                        </div>
                                    </label>
                                    <label class="cursor-pointer">
                                        <input type="radio" name="export-format" value="txt" class="peer sr-only">
                                        <div class="p-3.5 rounded-xl border border-slate-700/80 bg-slate-950/40 peer-checked:border-cyan-400 peer-checked:bg-cyan-950/20 transition-all flex items-center justify-between">
                                            <div>
                                                <div class="text-sm font-semibold text-white">Text File</div>
                                                <div class="text-[11px] text-slate-400 font-mono">Plain Text (Exact Header)</div>
                                            </div>
                                            <span class="text-xs font-mono text-cyan-400 font-bold">.txt</span>
                                        </div>
                                    </label>
                                </div>
                            </div>

                            <!-- Notice on Header Spec -->
                            <div class="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] font-mono text-slate-400 flex items-center space-x-2">
                                <svg class="w-4 h-4 text-cyan-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                                <span>Exported files will strictly feature header: <span class="text-cyan-300 font-bold">Email, Password, Recovery Mail</span></span>
                            </div>

                            <!-- Extraction Action Button -->
                            <button type="submit" id="btn-extract" class="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-600 hover:from-cyan-400 hover:to-sky-500 text-white font-bold text-sm tracking-wide shadow-cyber-cyan hover:shadow-cyan-500/50 transition-all flex items-center justify-center space-x-2">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                                <span>UNLOCK WITH PIN & DOWNLOAD</span>
                            </button>
                        </form>
                    </div>

                    <!-- TERMINAL B: REPLACEMENT RESOLUTION (5 cols) -->
                    <div class="lg:col-span-5 glass-panel rounded-2xl p-6 lg:p-8 relative">
                        <div class="flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
                            <div>
                                <h3 class="text-lg font-bold text-white flex items-center space-x-2">
                                    <svg class="w-5 h-5 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
                                    <span>Replacement Terminal</span>
                                </h3>
                                <p class="text-xs text-slate-400 mt-1">Submit faulty accounts to mark them as 'replaced'.</p>
                            </div>
                            <span class="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-500/10 text-amber-300 border border-amber-500/20">Audit Logged</span>
                        </div>

                        <form id="form-replace" onsubmit="VaultApp.handleReplacementSubmit(event)" class="space-y-4">
                            <div>
                                <div class="flex items-center justify-between mb-2">
                                    <label class="text-xs font-mono text-slate-300 uppercase tracking-wider">Faulty Email Accounts</label>
                                    <span class="text-[10px] font-mono text-slate-400">One email per line</span>
                                </div>
                                <textarea id="replace-emails" rows="8" required class="w-full p-3.5 bg-slate-950/80 border border-slate-700/80 rounded-xl text-white font-mono text-xs focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 custom-scroll transition-all" placeholder="badaccount1@bsis5.ch&#10;badaccount2@adlover.site"></textarea>
                            </div>

                            <p class="text-[11px] text-slate-400 font-mono">
                                The system validates each email in the database and shifts its status from <span class="text-cyan-300">downloaded</span> &rarr; <span class="text-amber-400 font-bold">replaced</span>.
                            </p>

                            <button type="submit" id="btn-replace" class="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-sm tracking-wide shadow-lg shadow-amber-500/20 hover:shadow-amber-500/40 transition-all flex items-center justify-center space-x-2">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                                <span>MARK ACCOUNTS AS REPLACED</span>
                            </button>
                        </form>
                    </div>

                </div>
            </section>


            <!-- VIEW 3: ADMIN CONSOLE (INGESTION, INVENTORY & AUDIT) -->
            <section id="view-admin" class="hidden space-y-8 animate__animated animate__fadeIn">
                <!-- Welcome Banner -->
                <div class="glass-panel rounded-2xl p-6 relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <div class="flex items-center space-x-2 mb-1">
                            <span class="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></span>
                            <span class="text-xs font-mono uppercase tracking-widest text-cyan-400">Master Administrator Console</span>
                        </div>
                        <h2 class="text-2xl font-bold text-white tracking-tight">Data Ingestion & Vault Command</h2>
                        <p class="text-xs text-slate-400 mt-0.5">Ingest new CSV inventories, auto-extract domains, prevent duplicates, and inspect stock.</p>
                    </div>
                    <div class="flex items-center space-x-3">
                        <button onclick="VaultApp.loadAdminData()" class="px-4 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-xs font-mono text-cyan-300 flex items-center space-x-2 transition-all">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
                            <span>Refresh Console</span>
                        </button>
                    </div>
                </div>

                <!-- OVERALL SYSTEM COUNTERS -->
                <div class="grid grid-cols-2 lg:grid-cols-4 gap-4" id="admin-overall-stats">
                    <div class="glass-panel rounded-xl p-5">
                        <div class="text-[11px] font-mono text-slate-400 uppercase">Total Stored</div>
                        <div id="stat-total" class="text-2xl font-bold font-mono text-white mt-1">--</div>
                    </div>
                    <div class="glass-panel rounded-xl p-5 border-emerald-500/30">
                        <div class="text-[11px] font-mono text-emerald-400 uppercase">Available Stock</div>
                        <div id="stat-available" class="text-2xl font-bold font-mono text-emerald-300 mt-1">--</div>
                    </div>
                    <div class="glass-panel rounded-xl p-5 border-cyan-500/30">
                        <div class="text-[11px] font-mono text-cyan-400 uppercase">Extracted / Downloaded</div>
                        <div id="stat-downloaded" class="text-2xl font-bold font-mono text-cyan-300 mt-1">--</div>
                    </div>
                    <div class="glass-panel rounded-xl p-5 border-amber-500/30">
                        <div class="text-[11px] font-mono text-amber-400 uppercase">Replaced (Faulty)</div>
                        <div id="stat-replaced" class="text-2xl font-bold font-mono text-amber-300 mt-1">--</div>
                    </div>
                </div>

                <!-- CSV INGESTION HUB -->
                <div class="glass-panel-glow rounded-2xl p-6 lg:p-8 relative">
                    <div class="flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
                        <div>
                            <h3 class="text-lg font-bold text-white flex items-center space-x-2">
                                <svg class="w-5 h-5 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/></svg>
                                <span>CSV Data Ingestion Terminal</span>
                            </h3>
                            <p class="text-xs text-slate-400 mt-1">Format required: 3 Columns (<span class="text-cyan-300 font-mono">Email, Password, Recovery Mail</span>). Domains auto-extracted, duplicates skipped.</p>
                        </div>
                        <button type="button" onclick="VaultApp.loadSampleCsv()" class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono border border-slate-700 transition-all flex items-center space-x-1.5">
                            <svg class="w-3.5 h-3.5 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2"/></svg>
                            <span>Insert Sample Data</span>
                        </button>
                    </div>

                    <form id="form-csv-upload" onsubmit="VaultApp.handleCsvUpload(event)" class="space-y-5">
                        <!-- Dropzone / File Picker -->
                        <div id="dropzone" onclick="document.getElementById('csv-file-input').click()" class="border-2 border-dashed border-slate-700 hover:border-cyan-400/80 rounded-2xl p-6 text-center cursor-pointer bg-slate-950/40 hover:bg-cyan-950/10 transition-all">
                            <input type="file" id="csv-file-input" accept=".csv,.txt" onchange="VaultApp.handleFileSelect(event)" class="hidden">
                            <div class="w-12 h-12 mx-auto mb-3 rounded-full bg-slate-800/80 text-cyan-400 flex items-center justify-center">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                            </div>
                            <div id="file-chosen-label" class="text-sm font-semibold text-white">Click or drag a CSV file here</div>
                            <div class="text-xs text-slate-500 font-mono mt-1">Supports standard CSV (.csv) or plain text (.txt)</div>
                        </div>

                        <!-- Raw Textarea Option -->
                        <div>
                            <div class="flex items-center justify-between mb-2">
                                <label class="text-xs font-mono text-slate-300 uppercase tracking-wider">Or Paste Raw CSV Data Directly</label>
                                <span class="text-[11px] font-mono text-slate-500">Email, Password, Recovery Mail</span>
                            </div>
                            <textarea id="csv-text-input" rows="5" class="w-full p-3.5 bg-slate-950/80 border border-slate-700 rounded-xl text-white font-mono text-xs focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 custom-scroll transition-all" placeholder="Email, Password, Recovery Mail&#10;user1@bsis5.ch,Secret123!,rec1@gmail.com&#10;user2@adlover.site,Pass456!,rec2@gmail.com"></textarea>
                        </div>

                        <button type="submit" id="btn-upload-csv" class="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold text-sm tracking-wide shadow-cyber-cyan hover:shadow-cyan-500/50 transition-all flex items-center justify-center space-x-2">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/></svg>
                            <span>PARSE & INGEST CSV INTO DATABASE</span>
                        </button>
                    </form>
                </div>

                <!-- INVENTORY ACCOUNTS TABLE -->
                <div class="glass-panel rounded-2xl p-6 lg:p-8">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                        <div>
                            <h3 class="text-lg font-bold text-white">Live Inventory Explorer</h3>
                            <p class="text-xs text-slate-400">Real-time status of stored email credentials</p>
                        </div>
                        <div class="flex items-center space-x-2">
                            <select id="filter-domain" onchange="VaultApp.loadAdminAccounts()" class="px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-slate-300 focus:outline-none focus:border-cyan-400">
                                <option value="">All Domains</option>
                                <option value="bsis5.ch">bsis5.ch</option>
                                <option value="adlover.site">adlover.site</option>
                            </select>
                            <select id="filter-status" onchange="VaultApp.loadAdminAccounts()" class="px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-slate-300 focus:outline-none focus:border-cyan-400">
                                <option value="">All Statuses</option>
                                <option value="available">Available</option>
                                <option value="downloaded">Downloaded</option>
                                <option value="replaced">Replaced</option>
                            </select>
                        </div>
                    </div>

                    <div class="overflow-x-auto custom-scroll">
                        <table class="w-full text-left text-xs text-slate-300">
                            <thead class="bg-slate-950/70 text-slate-400 font-mono uppercase tracking-wider border-b border-slate-800">
                                <tr>
                                    <th class="p-3">#ID</th>
                                    <th class="p-3">Email Account</th>
                                    <th class="p-3">Domain</th>
                                    <th class="p-3">Status</th>
                                    <th class="p-3">Ingested At</th>
                                    <th class="p-3">Action History</th>
                                </tr>
                            </thead>
                            <tbody id="admin-accounts-tbody" class="divide-y divide-slate-800/60 font-mono">
                                <tr>
                                    <td colspan="6" class="p-6 text-center text-slate-500">Loading accounts inventory...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </section>

        </main>

        <!-- Footer Bar -->
        <footer class="glass-panel border-t border-slate-800/80 py-4 px-4 text-center text-xs font-mono text-slate-500">
            <div class="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
                <div>CYBERVAULT v2.4 &bull; Apache Hostinger Production Architecture</div>
                <div>SQLite Strict Engine &bull; Zero-Spurious Characters &bull; SHA-256 CSRF</div>
            </div>
        </footer>
    </div>

    <!-- Frontend Core Application Logic -->
    <script>
        const VaultApp = {
            csrfToken: '<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>',
            user: null,
            managedDomains: <?= json_encode(MANAGED_DOMAINS) ?>,
            selectedExtractDomain: 'bsis5.ch',
            stocks: {},

            init: async function() {
                this.initParticles();
                await this.checkAuthStatus();
            },

            initParticles: function() {
                if (typeof particlesJS !== 'undefined') {
                    particlesJS('particles-js', {
                        particles: {
                            number: { value: 45, density: { enable: true, value_area: 800 } },
                            color: { value: ['#06b6d4', '#0ea5e9', '#3b82f6'] },
                            shape: { type: 'circle' },
                            opacity: { value: 0.25, random: true },
                            size: { value: 2.5, random: true },
                            line_linked: {
                                enable: true,
                                distance: 150,
                                color: '#06b6d4',
                                opacity: 0.15,
                                width: 1
                            },
                            move: {
                                enable: true,
                                speed: 1.2,
                                direction: 'none',
                                random: false,
                                straight: false,
                                out_mode: 'out',
                                bounce: false
                            }
                        },
                        interactivity: {
                            detect_on: 'canvas',
                            events: {
                                onhover: { enable: true, mode: 'grab' },
                                onclick: { enable: true, mode: 'push' },
                                resize: true
                            },
                            modes: {
                                grab: { distance: 140, line_linked: { opacity: 0.4 } },
                                push: { particles_nb: 3 }
                            }
                        },
                        retina_detect: true
                    });
                }
            },

            checkAuthStatus: async function() {
                try {
                    const res = await fetch('api.php?action=status');
                    const data = await res.json();
                    if (data.authenticated && data.user) {
                        this.user = data.user;
                        this.csrfToken = data.csrf_token || this.csrfToken;
                        this.showAuthenticatedView();
                    } else {
                        this.showLoginView();
                    }
                } catch (e) {
                    console.error('Status check failed:', e);
                    this.showLoginView();
                }
            },

            handleLogin: async function(e) {
                e.preventDefault();
                const u = document.getElementById('login-username').value.trim();
                const p = document.getElementById('login-password').value;

                if (!u || !p) return;

                const btn = document.getElementById('btn-login-submit');
                const origText = btn.innerHTML;
                btn.innerHTML = '<span>AUTHENTICATING...</span>';
                btn.disabled = true;

                try {
                    const formData = new FormData();
                    formData.append('username', u);
                    formData.append('password', p);
                    formData.append('csrf_token', this.csrfToken);

                    const res = await fetch('api.php?action=login', {
                        method: 'POST',
                        body: formData
                    });
                    const data = await res.json();

                    if (data.success) {
                        this.user = data.user;
                        this.csrfToken = data.csrf_token || this.csrfToken;
                        
                        Swal.fire({
                            customClass: { popup: 'cyber-swal' },
                            icon: 'success',
                            title: 'Access Granted',
                            text: `Welcome back, ${this.user.username} (${this.user.role.toUpperCase()})`,
                            timer: 1500,
                            showConfirmButton: false
                        });

                        this.showAuthenticatedView();
                    } else {
                        Swal.fire({
                            customClass: { popup: 'cyber-swal' },
                            icon: 'error',
                            title: 'Clearance Rejected',
                            text: data.message || 'Invalid credentials'
                        });
                    }
                } catch (err) {
                    Swal.fire({
                        customClass: { popup: 'cyber-swal' },
                        icon: 'error',
                        title: 'Connection Error',
                        text: 'Unable to communicate with the authentication server.'
                    });
                } finally {
                    btn.innerHTML = origText;
                    btn.disabled = false;
                }
            },

            logout: async function() {
                try {
                    await fetch('api.php?action=logout');
                } catch (e) {}
                this.user = null;
                this.showLoginView();
                Swal.fire({
                    customClass: { popup: 'cyber-swal' },
                    icon: 'info',
                    title: 'Session Terminated',
                    text: 'You have been securely logged out.',
                    timer: 1200,
                    showConfirmButton: false
                });
            },

            showLoginView: function() {
                document.getElementById('view-login').classList.remove('hidden');
                document.getElementById('view-client').classList.add('hidden');
                document.getElementById('view-admin').classList.add('hidden');
                document.getElementById('header-auth-badge').classList.add('hidden');
                document.getElementById('header-auth-badge').classList.remove('flex');
            },

            showAuthenticatedView: function() {
                document.getElementById('view-login').classList.add('hidden');
                document.getElementById('header-auth-badge').classList.remove('hidden');
                document.getElementById('header-auth-badge').classList.add('flex');
                document.getElementById('header-user-name').innerText = this.user.username;
                document.getElementById('header-user-role').innerText = this.user.role.toUpperCase();

                if (this.user.role === 'admin') {
                    document.getElementById('view-admin').classList.remove('hidden');
                    document.getElementById('view-client').classList.add('hidden');
                    this.loadAdminData();
                } else {
                    document.getElementById('view-client').classList.remove('hidden');
                    document.getElementById('view-admin').classList.add('hidden');
                    this.refreshStock();
                }
            },

            // ==========================================
            // Stock & Client Hub
            // ==========================================
            refreshStock: async function() {
                try {
                    const res = await fetch('api.php?action=stock');
                    const data = await res.json();
                    if (!data.success) return;

                    const grid = document.getElementById('client-stock-grid');
                    grid.innerHTML = '';
                    const domainOptions = document.getElementById('extract-domain-options');
                    domainOptions.innerHTML = '';

                    // Store stock index
                    data.domains.forEach((d) => {
                        this.stocks[d.domain] = d.available;

                        // Create Stock Card
                        const isPrimary = d.domain === 'bsis5.ch' || d.domain === 'adlover.site';
                        const card = document.createElement('div');
                        card.className = `glass-panel rounded-2xl p-6 relative overflow-hidden transition-all hover:border-cyan-500/50 ${isPrimary ? 'border-cyan-500/30' : ''}`;
                        card.innerHTML = `
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center space-x-2">
                                    <div class="w-3 h-3 rounded-full ${d.available > 0 ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500'}"></div>
                                    <span class="text-xs font-mono uppercase tracking-wider text-slate-400">Managed Domain</span>
                                </div>
                                <span class="px-2.5 py-0.5 rounded-full text-[11px] font-mono ${d.available > 0 ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-300 border border-rose-500/20'}">
                                    ${d.available > 0 ? 'Ready for Extraction' : 'Out of Stock'}
                                </span>
                            </div>
                            <div class="text-xl font-bold font-mono text-white mb-3 tracking-tight">${d.domain}</div>
                            <div class="grid grid-cols-3 gap-2 pt-3 border-t border-slate-800 text-center font-mono">
                                <div>
                                    <div class="text-[10px] text-slate-400 uppercase">Available</div>
                                    <div class="text-xl font-bold text-emerald-400">${d.available}</div>
                                </div>
                                <div>
                                    <div class="text-[10px] text-slate-400 uppercase">Extracted</div>
                                    <div class="text-xl font-bold text-cyan-400">${d.downloaded}</div>
                                </div>
                                <div>
                                    <div class="text-[10px] text-slate-400 uppercase">Replaced</div>
                                    <div class="text-xl font-bold text-amber-400">${d.replaced}</div>
                                </div>
                            </div>
                        `;
                        grid.appendChild(card);

                        // Populate extraction domain radio buttons
                        const opt = document.createElement('label');
                        opt.className = 'cursor-pointer';
                        opt.innerHTML = `
                            <input type="radio" name="extract-domain" value="${d.domain}" ${d.domain === this.selectedExtractDomain ? 'checked' : ''} onchange="VaultApp.onDomainChanged('${d.domain}')" class="peer sr-only">
                            <div class="p-3.5 rounded-xl border border-slate-700/80 bg-slate-950/40 peer-checked:border-cyan-400 peer-checked:bg-cyan-950/20 transition-all flex items-center justify-between">
                                <div>
                                    <div class="text-sm font-semibold text-white font-mono">${d.domain}</div>
                                    <div class="text-[11px] text-slate-400 font-mono">${d.available} in stock</div>
                                </div>
                                <span class="w-3.5 h-3.5 rounded-full border-2 border-slate-600 peer-checked:border-cyan-400 peer-checked:bg-cyan-400"></span>
                            </div>
                        `;
                        domainOptions.appendChild(opt);
                    });

                    this.updateAvailableHint();

                } catch (e) {
                    console.error('Failed to refresh stock:', e);
                }
            },

            onDomainChanged: function(domain) {
                this.selectedExtractDomain = domain;
                this.updateAvailableHint();
            },

            updateAvailableHint: function() {
                const avail = this.stocks[this.selectedExtractDomain] || 0;
                document.getElementById('extract-stock-hint').innerText = `Available: ${avail}`;
            },

            setExtractQty: function(val) {
                const avail = this.stocks[this.selectedExtractDomain] || 0;
                const input = document.getElementById('extract-quantity');
                if (val === 'max') {
                    input.value = Math.max(1, avail);
                } else {
                    input.value = val;
                }
            },

            // ==========================================
            // Extraction & SweetAlert2 PIN Workflow
            // ==========================================
            handleExtractSubmit: function(e) {
                e.preventDefault();
                const domain = this.selectedExtractDomain;
                const qty = parseInt(document.getElementById('extract-quantity').value, 10);
                const format = document.querySelector('input[name="export-format"]:checked')?.value || 'csv';

                if (!domain) {
                    Swal.fire({ customClass: { popup: 'cyber-swal' }, icon: 'warning', title: 'Domain Required', text: 'Please select a domain to extract.' });
                    return;
                }

                if (!qty || qty <= 0) {
                    Swal.fire({ customClass: { popup: 'cyber-swal' }, icon: 'warning', title: 'Invalid Quantity', text: 'Please enter a valid extraction quantity.' });
                    return;
                }

                const avail = this.stocks[domain] || 0;
                if (qty > avail) {
                    Swal.fire({
                        customClass: { popup: 'cyber-swal' },
                        icon: 'error',
                        title: 'Stock Exceeded',
                        text: `Only ${avail} accounts currently available for ${domain}. Requested: ${qty}`
                    });
                    return;
                }

                // Show SweetAlert2 PIN dialog
                Swal.fire({
                    customClass: { popup: 'cyber-swal' },
                    title: 'SECURE EXTRACTION PIN',
                    html: `
                        <p class="text-xs text-slate-300 mb-3">Authorize extraction of <b class="text-cyan-300 font-mono">${qty}</b> accounts from <b class="text-cyan-300 font-mono">${domain}</b> (${format.toUpperCase()})</p>
                        <p class="text-[11px] text-slate-400 font-mono">Enter your 4-digit security PIN:</p>
                    `,
                    input: 'password',
                    inputPlaceholder: '••••',
                    inputAttributes: {
                        maxlength: 4,
                        autocapitalize: 'off',
                        autocorrect: 'off'
                    },
                    showCancelButton: true,
                    confirmButtonText: 'AUTHENTICATE & EXTRACT',
                    confirmButtonColor: '#06b6d4',
                    cancelButtonText: 'Abort',
                    cancelButtonColor: '#334155',
                    showLoaderOnConfirm: true,
                    preConfirm: async (pin) => {
                        if (!pin || pin.length !== 4) {
                            Swal.showValidationMessage('A valid 4-digit PIN is required');
                            return false;
                        }

                        const formData = new FormData();
                        formData.append('domain', domain);
                        formData.append('quantity', qty);
                        formData.append('format', format);
                        formData.append('pin', pin);
                        formData.append('csrf_token', this.csrfToken);

                        try {
                            const res = await fetch('api.php?action=extract', {
                                method: 'POST',
                                body: formData
                            });
                            const data = await res.json();
                            if (!data.success) {
                                Swal.showValidationMessage(data.message || 'Extraction failed');
                                return false;
                            }
                            return data;
                        } catch (err) {
                            Swal.showValidationMessage('Server communication error');
                            return false;
                        }
                    }
                }).then((result) => {
                    if (result.isConfirmed && result.value) {
                        const data = result.value;
                        // Trigger force download of the base64 content
                        this.downloadBase64File(data.file_content, data.filename, data.format === 'csv' ? 'text/csv' : 'text/plain');

                        Swal.fire({
                            customClass: { popup: 'cyber-swal' },
                            icon: 'success',
                            title: 'Extraction Successful',
                            html: `
                                <div class="text-xs text-slate-300 space-y-1">
                                    <p>Downloaded: <b class="text-cyan-300 font-mono">${data.extracted}</b> accounts</p>
                                    <p>Domain: <b class="text-white font-mono">${data.domain}</b></p>
                                    <p>Header: <code class="text-emerald-300">email,password,recovery email</code> (bina space)</p>
                                    <p class="text-[11px] text-slate-400 mt-2">File <b>${data.filename}</b> downloaded to your system.</p>
                                </div>
                            `
                        });

                        // Refresh stock numbers
                        this.refreshStock();
                        document.getElementById('extract-quantity').value = '';
                    }
                });
            },

            downloadBase64File: function(base64Content, filename, mimeType) {
                const byteCharacters = atob(base64Content);
                const byteNumbers = new Array(byteCharacters.length);
                for (let i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                const byteArray = new Uint8Array(byteNumbers);
                const blob = new Blob([byteArray], { type: mimeType });
                
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = filename;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(link.href);
            },

            // ==========================================
            // Replacement Feature
            // ==========================================
            handleReplacementSubmit: async function(e) {
                e.preventDefault();
                const raw = document.getElementById('replace-emails').value.trim();
                if (!raw) return;

                const btn = document.getElementById('btn-replace');
                const origText = btn.innerHTML;
                btn.innerHTML = '<span>PROCESSING REPLACEMENTS...</span>';
                btn.disabled = true;

                try {
                    const formData = new FormData();
                    formData.append('faulty_emails', raw);
                    formData.append('csrf_token', this.csrfToken);

                    const res = await fetch('api.php?action=replace', {
                        method: 'POST',
                        body: formData
                    });
                    const data = await res.json();

                    if (data.success) {
                        let detailsHtml = `<p class="text-sm font-semibold text-white mb-2">${data.message}</p>`;
                        if (data.not_found && data.not_found.length > 0) {
                            detailsHtml += `<p class="text-xs text-rose-300 mt-1">Not Found in DB: ${data.not_found.join(', ')}</p>`;
                        }
                        if (data.not_downloaded && data.not_downloaded.length > 0) {
                            detailsHtml += `<p class="text-xs text-amber-300 mt-1">Not in 'downloaded' state: ${data.not_downloaded.map(x => x.email + ' (' + x.status + ')').join(', ')}</p>`;
                        }

                        Swal.fire({
                            customClass: { popup: 'cyber-swal' },
                            icon: 'success',
                            title: 'Replacements Recorded',
                            html: detailsHtml
                        });

                        document.getElementById('replace-emails').value = '';
                        this.refreshStock();
                    } else {
                        Swal.fire({
                            customClass: { popup: 'cyber-swal' },
                            icon: 'error',
                            title: 'Replacement Issue',
                            text: data.message || 'Failed to update replacement status'
                        });
                    }
                } catch (err) {
                    Swal.fire({
                        customClass: { popup: 'cyber-swal' },
                        icon: 'error',
                        title: 'Error',
                        text: 'Server communication error during replacement.'
                    });
                } finally {
                    btn.innerHTML = origText;
                    btn.disabled = false;
                }
            },

            // ==========================================
            // Admin: Load Data, CSV Upload, Inventory
            // ==========================================
            loadAdminData: async function() {
                await Promise.all([
                    this.loadAdminStats(),
                    this.loadAdminAccounts()
                ]);
            },

            loadAdminStats: async function() {
                try {
                    const res = await fetch('api.php?action=stock');
                    const data = await res.json();
                    if (!data.success) return;

                    const o = data.overall;
                    document.getElementById('stat-total').innerText = o.total_accounts;
                    document.getElementById('stat-available').innerText = o.total_available;
                    document.getElementById('stat-downloaded').innerText = o.total_downloaded;
                    document.getElementById('stat-replaced').innerText = o.total_replaced;
                } catch (e) {
                    console.error('Failed to load admin stats:', e);
                }
            },

            loadAdminAccounts: async function() {
                const domain = document.getElementById('filter-domain').value;
                const status = document.getElementById('filter-status').value;

                try {
                    const res = await fetch(`api.php?action=list_accounts&domain=${encodeURIComponent(domain)}&status=${encodeURIComponent(status)}&limit=100`);
                    const data = await res.json();
                    if (!data.success) return;

                    const tbody = document.getElementById('admin-accounts-tbody');
                    tbody.innerHTML = '';

                    if (!data.accounts || data.accounts.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="6" class="p-6 text-center text-slate-500 font-mono">No accounts match current filters</td></tr>';
                        return;
                    }

                    data.accounts.forEach((acc) => {
                        const tr = document.createElement('tr');
                        tr.className = 'hover:bg-slate-900/50 transition-colors';

                        let statusBadge = '';
                        if (acc.status === 'available') {
                            statusBadge = '<span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">available</span>';
                        } else if (acc.status === 'downloaded') {
                            statusBadge = '<span class="px-2 py-0.5 rounded text-[10px] bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">downloaded</span>';
                        } else if (acc.status === 'replaced') {
                            statusBadge = '<span class="px-2 py-0.5 rounded text-[10px] bg-amber-500/10 text-amber-300 border border-amber-500/20">replaced</span>';
                        }

                        tr.innerHTML = `
                            <td class="p-3 text-slate-500">${acc.id}</td>
                            <td class="p-3 text-white font-semibold">${acc.email}</td>
                            <td class="p-3 text-cyan-300">${acc.domain}</td>
                            <td class="p-3">${statusBadge}</td>
                            <td class="p-3 text-slate-400 text-[11px]">${acc.created_at}</td>
                            <td class="p-3 text-slate-400 text-[11px]">${acc.downloaded_at ? 'DL: ' + acc.downloaded_at : (acc.replaced_at ? 'Repl: ' + acc.replaced_at : 'None')}</td>
                        `;
                        tbody.appendChild(tr);
                    });

                } catch (e) {
                    console.error('Failed to load accounts list:', e);
                }
            },

            handleFileSelect: function(e) {
                const file = e.target.files[0];
                if (file) {
                    document.getElementById('file-chosen-label').innerHTML = `<span class="text-cyan-400 font-mono">${file.name}</span> (${(file.size / 1024).toFixed(1)} KB)`;
                }
            },

            loadSampleCsv: function() {
                const sample = [
                    "email,password,recovery email",
                    "alpha_01@bsis5.ch,VaultP@ss101,recovery1@gmail.com",
                    "alpha_02@bsis5.ch,VaultP@ss102,recovery2@gmail.com",
                    "alpha_03@bsis5.ch,VaultP@ss103,recovery3@gmail.com",
                    "beta_01@adlover.site,CyberSec!201,sec_rec1@yahoo.com",
                    "beta_02@adlover.site,CyberSec!202,sec_rec2@yahoo.com",
                    "beta_03@adlover.site,CyberSec!203,sec_rec3@yahoo.com"
                ].join("\n");

                document.getElementById('csv-text-input').value = sample;
                Swal.fire({
                    customClass: { popup: 'cyber-swal' },
                    icon: 'info',
                    title: 'Sample CSV Populated',
                    text: 'Loaded 6 sample records covering bsis5.ch and adlover.site',
                    timer: 1200,
                    showConfirmButton: false
                });
            },

            handleCsvUpload: async function(e) {
                e.preventDefault();
                const fileInput = document.getElementById('csv-file-input');
                const rawText = document.getElementById('csv-text-input').value.trim();

                if (!fileInput.files[0] && !rawText) {
                    Swal.fire({
                        customClass: { popup: 'cyber-swal' },
                        icon: 'warning',
                        title: 'No Data Provided',
                        text: 'Please select a CSV file or paste CSV text to ingest.'
                    });
                    return;
                }

                const btn = document.getElementById('btn-upload-csv');
                const origText = btn.innerHTML;
                btn.innerHTML = '<span>PARSING & INGESTING...</span>';
                btn.disabled = true;

                try {
                    const formData = new FormData();
                    if (fileInput.files[0]) {
                        formData.append('csv_file', fileInput.files[0]);
                    }
                    if (rawText) {
                        formData.append('csv_text', rawText);
                    }
                    formData.append('csrf_token', this.csrfToken);

                    const res = await fetch('api.php?action=upload_csv', {
                        method: 'POST',
                        body: formData
                    });
                    const data = await res.json();

                    if (data.success) {
                        // Success popup showing count of newly added emails
                        let breakdownHtml = '';
                        if (data.domain_breakdown && Object.keys(data.domain_breakdown).length > 0) {
                            breakdownHtml = '<div class="mt-2 text-left bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-xs font-mono">';
                            for (const [dom, cnt] of Object.entries(data.domain_breakdown)) {
                                breakdownHtml += `<div>&bull; <span class="text-cyan-300 font-semibold">${dom}</span>: +${cnt} added</div>`;
                            }
                            breakdownHtml += '</div>';
                        }

                        Swal.fire({
                            customClass: { popup: 'cyber-swal' },
                            icon: 'success',
                            title: 'Ingestion Completed',
                            html: `
                                <div class="text-xs text-slate-300 space-y-1.5">
                                    <p class="text-sm font-bold text-emerald-400 font-mono">+${data.inserted} New Accounts Added</p>
                                    <p>Total Rows Evaluated: <b class="text-white">${data.total_rows}</b></p>
                                    <p>Duplicates Skipped: <b class="text-amber-400">${data.duplicates}</b></p>
                                    ${data.invalid > 0 ? `<p class="text-rose-400">Invalid Format: ${data.invalid}</p>` : ''}
                                    ${breakdownHtml}
                                </div>
                            `
                        });

                        // Clear inputs
                        fileInput.value = '';
                        document.getElementById('csv-text-input').value = '';
                        document.getElementById('file-chosen-label').innerText = 'Click or drag a CSV file here';

                        this.loadAdminData();
                    } else {
                        Swal.fire({
                            customClass: { popup: 'cyber-swal' },
                            icon: 'error',
                            title: 'Ingestion Error',
                            text: data.message || 'Could not parse or insert CSV'
                        });
                    }
                } catch (err) {
                    Swal.fire({
                        customClass: { popup: 'cyber-swal' },
                        icon: 'error',
                        title: 'Upload Error',
                        text: 'Communication error with server during CSV ingestion.'
                    });
                } finally {
                    btn.innerHTML = origText;
                    btn.disabled = false;
                }
            }
        };

        document.addEventListener('DOMContentLoaded', () => {
            VaultApp.init();
        });
    </script>
</body>
</html>
