<?php
/**
 * Single-Tenant Email Accounts Vault - Unified API Engine
 * Handles Authentication, Stock Levels, CSV Ingestion, Secure Extraction, and Replacements.
 */

declare(strict_types=1);

define('VAULT_APP', true);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

Auth::initSession();

// Set default response headers for JSON
$action = $_GET['action'] ?? $_POST['action'] ?? '';

// Allow direct download action to stream file directly without JSON header
if ($action !== 'download_file') {
    header('Content-Type: application/json; charset=utf-8');
}

// Error helper
function respondJson(array $data, int $statusCode = 200): void {
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    $pdo = Database::getConnection();

    switch ($action) {
        // ==========================================
        // Auth Status Check
        // ==========================================
        case 'status':
            $user = Auth::user();
            respondJson([
                'authenticated' => Auth::isLoggedIn(),
                'user'          => $user,
                'csrf_token'    => Auth::getCsrfToken(),
                'managed_domains' => MANAGED_DOMAINS
            ]);
            break;

        // ==========================================
        // User Login
        // ==========================================
        case 'login':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                respondJson(['success' => false, 'message' => 'Method not allowed'], 405);
            }

            // Verify CSRF
            if (!Auth::verifyCsrfToken()) {
                respondJson(['success' => false, 'message' => 'Security token mismatch. Please refresh.'], 403);
            }

            $username = (string)($_POST['username'] ?? '');
            $password = (string)($_POST['password'] ?? '');

            $result = Auth::login($username, $password);
            if ($result['success']) {
                respondJson([
                    'success'    => true,
                    'user'       => Auth::user(),
                    'csrf_token' => Auth::getCsrfToken(),
                    'message'    => 'Authentication successful'
                ]);
            } else {
                respondJson($result, 401);
            }
            break;

        // ==========================================
        // User Logout
        // ==========================================
        case 'logout':
            Auth::logout();
            respondJson(['success' => true, 'message' => 'Logged out successfully']);
            break;

        // ==========================================
        // Real-Time Stock Counts
        // ==========================================
        case 'stock':
            if (!Auth::isLoggedIn()) {
                respondJson(['success' => false, 'message' => 'Unauthorized'], 401);
            }

            // Group count by domain and status
            $stmt = $pdo->query("
                SELECT domain, status, COUNT(*) as count 
                FROM emails 
                GROUP BY domain, status
            ");
            $rows = $stmt->fetchAll();

            $domainStats = [];
            // Pre-seed managed domains so they always exist even with 0 counts
            foreach (MANAGED_DOMAINS as $d) {
                $domainStats[$d] = [
                    'domain'     => $d,
                    'available'  => 0,
                    'downloaded' => 0,
                    'replaced'   => 0,
                    'total'      => 0
                ];
            }

            foreach ($rows as $row) {
                $d = $row['domain'];
                $s = $row['status'];
                $c = (int)$row['count'];

                if (!isset($domainStats[$d])) {
                    $domainStats[$d] = [
                        'domain'     => $d,
                        'available'  => 0,
                        'downloaded' => 0,
                        'replaced'   => 0,
                        'total'      => 0
                    ];
                }

                if (isset($domainStats[$d][$s])) {
                    $domainStats[$d][$s] += $c;
                }
                $domainStats[$d]['total'] += $c;
            }

            // Overall totals
            $totalsStmt = $pdo->query("
                SELECT 
                    COUNT(*) as total_accounts,
                    SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as total_available,
                    SUM(CASE WHEN status = 'downloaded' THEN 1 ELSE 0 END) as total_downloaded,
                    SUM(CASE WHEN status = 'replaced' THEN 1 ELSE 0 END) as total_replaced
                FROM emails
            ");
            $overall = $totalsStmt->fetch();

            respondJson([
                'success'         => true,
                'domains'         => array_values($domainStats),
                'managed_domains' => MANAGED_DOMAINS,
                'overall'         => [
                    'total_accounts'   => (int)($overall['total_accounts'] ?? 0),
                    'total_available'  => (int)($overall['total_available'] ?? 0),
                    'total_downloaded' => (int)($overall['total_downloaded'] ?? 0),
                    'total_replaced'   => (int)($overall['total_replaced'] ?? 0),
                ]
            ]);
            break;

        // ==========================================
        // Admin: CSV Ingestion
        // ==========================================
        case 'upload_csv':
            if (!Auth::isAdmin()) {
                respondJson(['success' => false, 'message' => 'Admin authorization required.'], 403);
            }

            if (!Auth::verifyCsrfToken()) {
                respondJson(['success' => false, 'message' => 'Security token invalid.'], 403);
            }

            $csvContent = '';

            // Handle uploaded file or raw text input
            if (!empty($_FILES['csv_file']['tmp_name'])) {
                if ($_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
                    respondJson(['success' => false, 'message' => 'File upload error occurred.'], 400);
                }
                $csvContent = file_get_contents($_FILES['csv_file']['tmp_name']);
            } elseif (!empty($_POST['csv_text'])) {
                $csvContent = (string)$_POST['csv_text'];
            } else {
                respondJson(['success' => false, 'message' => 'No CSV file or text provided.'], 400);
            }

            if (empty(trim($csvContent))) {
                respondJson(['success' => false, 'message' => 'The provided CSV content is empty.'], 400);
            }

            // Parse lines safely
            $lines = preg_split("/\r\n|\n|\r/", trim($csvContent));
            if (empty($lines)) {
                respondJson(['success' => false, 'message' => 'No valid records found in CSV.'], 400);
            }

            $totalRows = 0;
            $insertedCount = 0;
            $duplicateCount = 0;
            $invalidCount = 0;
            $domainCounts = [];

            // Detect if first line is header: Email, Password, Recovery Mail
            $firstLine = strtolower(trim($lines[0]));
            $startIndex = 0;
            if (strpos($firstLine, 'email') !== false && strpos($firstLine, 'password') !== false) {
                $startIndex = 1;
            }

            $pdo->beginTransaction();
            $stmt = $pdo->prepare("
                INSERT OR IGNORE INTO emails (email, password, recovery_email, domain, status) 
                VALUES (?, ?, ?, ?, 'available')
            ");

            for ($i = $startIndex; $i < count($lines); $i++) {
                $line = trim($lines[$i]);
                if (empty($line)) {
                    continue;
                }

                $totalRows++;
                $cols = str_getcsv($line);

                $email = trim($cols[0] ?? '');
                $password = trim($cols[1] ?? '');
                $recovery = trim($cols[2] ?? '');

                // Basic validation
                if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $invalidCount++;
                    continue;
                }

                if (empty($password)) {
                    $invalidCount++;
                    continue;
                }

                // Automatically extract domain from email
                $atPos = strrpos($email, '@');
                if ($atPos === false) {
                    $invalidCount++;
                    continue;
                }
                $domain = strtolower(substr($email, $atPos + 1));

                // Execute INSERT OR IGNORE
                $stmt->execute([$email, $password, $recovery, $domain]);
                
                if ($stmt->rowCount() > 0) {
                    $insertedCount++;
                    $domainCounts[$domain] = ($domainCounts[$domain] ?? 0) + 1;
                } else {
                    $duplicateCount++;
                }
            }

            $pdo->commit();

            // Log action
            Database::logAudit(
                Auth::user()['username'] ?? 'Hadi',
                'admin',
                'CSV_UPLOAD',
                "Imported {$insertedCount} accounts, {$duplicateCount} duplicates ignored, {$invalidCount} invalid."
            );

            respondJson([
                'success'         => true,
                'total_rows'      => $totalRows,
                'inserted'        => $insertedCount,
                'duplicates'      => $duplicateCount,
                'invalid'         => $invalidCount,
                'domain_breakdown'=> $domainCounts,
                'message'         => "Successfully added {$insertedCount} new email accounts. ({$duplicateCount} duplicates ignored)."
            ]);
            break;

        // ==========================================
        // Client: Extraction with Secure PIN
        // ==========================================
        case 'extract':
            if (!Auth::isClient() && !Auth::isAdmin()) {
                respondJson(['success' => false, 'message' => 'Unauthorized access.'], 403);
            }

            if (!Auth::verifyCsrfToken()) {
                respondJson(['success' => false, 'message' => 'Security token invalid.'], 403);
            }

            $domain = trim((string)($_POST['domain'] ?? ''));
            $quantity = (int)($_POST['quantity'] ?? 0);
            $format = strtolower(trim((string)($_POST['format'] ?? 'csv')));
            $pin = (string)($_POST['pin'] ?? '');

            if (empty($domain)) {
                respondJson(['success' => false, 'message' => 'Please select a domain.'], 400);
            }

            if ($quantity <= 0) {
                respondJson(['success' => false, 'message' => 'Please specify a quantity greater than zero.'], 400);
            }

            if (!in_array($format, ['csv', 'txt'], true)) {
                $format = 'csv';
            }

            // CRITICAL: Validate Secure Extraction PIN
            if (!Auth::verifyExtractionPin($pin)) {
                Database::logAudit(
                    Auth::user()['username'] ?? 'rana asim',
                    Auth::user()['role'] ?? 'client',
                    'EXTRACTION_PIN_FAILED',
                    "Failed extraction attempt for {$quantity} accounts of {$domain} with incorrect PIN"
                );
                respondJson([
                    'success' => false, 
                    'message' => 'Access Denied: Invalid 4-digit Secure Extraction PIN.'
                ], 403);
            }

            // Execute extraction within an immediate exclusive transaction
            $pdo->beginTransaction();

            // Check currently available count
            $stockCheck = $pdo->prepare("
                SELECT COUNT(*) FROM emails WHERE domain = ? AND status = 'available'
            ");
            $stockCheck->execute([$domain]);
            $availableStock = (int)$stockCheck->fetchColumn();

            if ($availableStock < $quantity) {
                $pdo->rollBack();
                respondJson([
                    'success' => false,
                    'message' => "Insufficient stock. Only {$availableStock} available for {$domain} (requested {$quantity})."
                ], 400);
            }

            // Fetch records to extract
            $fetchStmt = $pdo->prepare("
                SELECT id, email, password, recovery_email 
                FROM emails 
                WHERE domain = ? AND status = 'available' 
                ORDER BY id ASC 
                LIMIT ?
            ");
            $fetchStmt->execute([$domain, $quantity]);
            $records = $fetchStmt->fetchAll();

            if (empty($records)) {
                $pdo->rollBack();
                respondJson(['success' => false, 'message' => 'No accounts available for extraction.'], 400);
            }

            // Extract IDs to update
            $ids = array_column($records, 'id');
            $placeholders = implode(',', array_fill(0, count($ids), '?'));

            // Update status to 'downloaded'
            $updateStmt = $pdo->prepare("
                UPDATE emails 
                SET status = 'downloaded', downloaded_at = CURRENT_TIMESTAMP 
                WHERE id IN ($placeholders)
            ");
            $updateStmt->execute($ids);

            // Insert into orders history
            $orderCount = (int)$pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn() + 1;
            $orderNumber = "Order #" . $orderCount;
            $orderStmt = $pdo->prepare("
                INSERT INTO orders (order_number, client_username, domain, quantity, format, accounts_json)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $orderStmt->execute([
                $orderNumber,
                Auth::user()['username'] ?? 'rana asim',
                $domain,
                count($records),
                $format,
                json_encode($records)
            ]);

            $pdo->commit();

            // Log extraction audit
            Database::logAudit(
                Auth::user()['username'] ?? 'rana asim',
                Auth::user()['role'] ?? 'client',
                'EXTRACTION_SUCCESS',
                "Extracted {$quantity} accounts from domain {$domain} as {$format} ({$orderNumber})"
            );

            // Construct exact export file content with exact required header: email,password,recovery email
            $fileLines = [];
            $fileLines[] = "email,password,recovery email";

            foreach ($records as $r) {
                $fileLines[] = sprintf('%s,%s,%s', $r['email'], $r['password'], $r['recovery_email'] ?? '');
            }

            $exportContent = implode("\r\n", $fileLines) . "\r\n";
            $filename = sprintf('%s_%s_%s.%s', str_replace(' ', '_', $orderNumber), str_replace('.', '_', $domain), date('Ymd_His'), $format);

            respondJson([
                'success'      => true,
                'order_number' => $orderNumber,
                'extracted'    => count($records),
                'domain'       => $domain,
                'format'       => $format,
                'filename'     => $filename,
                'file_content' => base64_encode($exportContent),
                'message'      => "{$orderNumber}: Extracted " . count($records) . " accounts successfully."
            ]);
            break;

        // ==========================================
        // Orders History
        // ==========================================
        case 'orders':
            if (!Auth::isLoggedIn()) {
                respondJson(['success' => false, 'message' => 'Unauthorized'], 401);
            }

            $ordersStmt = $pdo->query("SELECT * FROM orders ORDER BY id DESC");
            $ordersList = $ordersStmt->fetchAll();
            foreach ($ordersList as &$o) {
                $o['accounts'] = json_decode($o['accounts_json'], true) ?: [];
                unset($o['accounts_json']);
            }

            respondJson([
                'success' => true,
                'orders'  => $ordersList
            ]);
            break;

        // ==========================================
        // Client: Replacement Feature
        // ==========================================
        case 'replace':
            if (!Auth::isClient() && !Auth::isAdmin()) {
                respondJson(['success' => false, 'message' => 'Unauthorized access.'], 403);
            }

            if (!Auth::verifyCsrfToken()) {
                respondJson(['success' => false, 'message' => 'Security token invalid.'], 403);
            }

            $rawText = (string)($_POST['faulty_emails'] ?? '');
            if (empty(trim($rawText))) {
                respondJson(['success' => false, 'message' => 'Please provide at least one faulty email address.'], 400);
            }

            // Split by lines, commas, spaces
            $rawLines = preg_split("/[\r\n,]+/", trim($rawText));
            $emailsToReplace = [];

            foreach ($rawLines as $item) {
                $clean = trim($item);
                if (!empty($clean) && filter_var($clean, FILTER_VALIDATE_EMAIL)) {
                    $emailsToReplace[] = strtolower($clean);
                }
            }

            $emailsToReplace = array_unique($emailsToReplace);

            if (empty($emailsToReplace)) {
                respondJson(['success' => false, 'message' => 'No valid email addresses detected in input.'], 400);
            }

            $pdo->beginTransaction();

            $replacedCount = 0;
            $notFound = [];
            $notDownloaded = [];

            $checkStmt = $pdo->prepare("SELECT email, status FROM emails WHERE email = ?");
            $updateStmt = $pdo->prepare("
                UPDATE emails 
                SET status = 'replaced', replaced_at = CURRENT_TIMESTAMP 
                WHERE email = ? AND status = 'downloaded'
            ");

            foreach ($emailsToReplace as $email) {
                $checkStmt->execute([$email]);
                $record = $checkStmt->fetch();

                if (!$record) {
                    $notFound[] = $email;
                    continue;
                }

                if ($record['status'] !== 'downloaded') {
                    $notDownloaded[] = [
                        'email'  => $email,
                        'status' => $record['status']
                    ];
                    continue;
                }

                // Update to replaced
                $updateStmt->execute([$email]);
                if ($updateStmt->rowCount() > 0) {
                    $replacedCount++;
                }
            }

            $pdo->commit();

            Database::logAudit(
                Auth::user()['username'] ?? 'rana asim',
                Auth::user()['role'] ?? 'client',
                'REPLACEMENT_SUBMITTED',
                "Processed replacement for " . count($emailsToReplace) . " emails: {$replacedCount} replaced."
            );

            respondJson([
                'success'        => true,
                'total_submitted'=> count($emailsToReplace),
                'replaced_count' => $replacedCount,
                'not_found'      => $notFound,
                'not_downloaded' => $notDownloaded,
                'message'        => "{$replacedCount} faulty email accounts marked as 'replaced'."
            ]);
            break;

        // ==========================================
        // Admin: View Inventory Accounts Table
        // ==========================================
        case 'list_accounts':
            if (!Auth::isAdmin()) {
                respondJson(['success' => false, 'message' => 'Admin authorization required.'], 403);
            }

            $domainFilter = trim((string)($_GET['domain'] ?? ''));
            $statusFilter = trim((string)($_GET['status'] ?? ''));
            $search = trim((string)($_GET['search'] ?? ''));
            $limit = min(200, max(10, (int)($_GET['limit'] ?? 50)));

            $sql = "SELECT id, email, domain, status, created_at, downloaded_at, replaced_at FROM emails WHERE 1=1";
            $params = [];

            if (!empty($domainFilter)) {
                $sql .= " AND domain = ?";
                $params[] = $domainFilter;
            }

            if (!empty($statusFilter)) {
                $sql .= " AND status = ?";
                $params[] = $statusFilter;
            }

            if (!empty($search)) {
                $sql .= " AND (email LIKE ? OR recovery_email LIKE ?)";
                $params[] = "%{$search}%";
                $params[] = "%{$search}%";
            }

            $sql .= " ORDER BY id DESC LIMIT ?";
            $params[] = $limit;

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $accounts = $stmt->fetchAll();

            respondJson([
                'success'  => true,
                'accounts' => $accounts
            ]);
            break;

        // ==========================================
        // Audit Logs (Recent events)
        // ==========================================
        case 'audit_logs':
            if (!Auth::isLoggedIn()) {
                respondJson(['success' => false, 'message' => 'Unauthorized'], 401);
            }

            $limit = Auth::isAdmin() ? 50 : 20;
            $stmt = $pdo->prepare("
                SELECT username, role, action, details, created_at 
                FROM audit_logs 
                ORDER BY id DESC 
                LIMIT ?
            ");
            $stmt->execute([$limit]);
            $logs = $stmt->fetchAll();

            respondJson([
                'success' => true,
                'logs'    => $logs
            ]);
            break;

        default:
            respondJson([
                'success' => false,
                'message' => "Unknown API action: {$action}"
            ], 404);
            break;
    }
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('API Exception: ' . $e->getMessage());
    respondJson([
        'success' => false,
        'message' => 'Server error: ' . $e->getMessage()
    ], 500);
}
