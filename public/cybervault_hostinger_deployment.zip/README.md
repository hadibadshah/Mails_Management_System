# HADI DIGITAL - Single-Tenant Account Distribution Portal
### Hostinger Deployment Guide (PHP + SQLite)

**Target Subdomain:** `asim.eztoolbox.xyz`  
**Target Directory:** `public_html/asim/`

---

### 1. Credentials & Login Details
- **Admin Login:**
  - Username: `Hadi`
  - Password: `91199119`
- **Client Login:**
  - Username: `rana asim`
  - Password: `rana@123`
- **Secure Extraction PIN:**
  - `1234`
- **CSV Column Header Format (bina space ke):**
  - `email,password,recovery email`

---

### 2. Files List
```
public_html/asim/
├── .htaccess             # Apache protection, disables directory listing, blocks direct .sqlite access
├── config.php            # Master credentials, PIN, managed domains, SQLite path
├── db.php                # PDO SQLite connector, auto-initialization, WAL mode, schema & indexes
├── auth.php              # Session hardening, CSRF tokens, role-based authorization
├── api.php               # Unified JSON & extraction file-stream API router
├── index.php             # Single-page UI with Tailwind, SweetAlert2, and client/admin panels
└── db/
    └── .htaccess         # "Require all denied" to prevent direct browser downloads
```

---

### 3. Step-by-Step Hostinger Deployment (5 Minutes):

1. **Open Hostinger hPanel**:
   - Go to `hostinger.com` and log in.
   - Go to **Websites** -> Click **Manage** on `eztoolbox.xyz`.

2. **Open File Manager**:
   - In the sidebar or search bar, click on **File Manager**.
   - Click on **public_html**.
   - Open your **`asim`** folder (`public_html/asim/`).

3. **Upload the Files**:
   - Upload all files from this package (`index.php`, `api.php`, `auth.php`, `config.php`, `db.php`, `.htaccess`, and the `db` folder) directly into `public_html/asim/`.
   - *Tip:* If uploading as a ZIP file, upload `hadi_digital_hostinger.zip` into `public_html/asim/` and click **Extract**.

4. **Verify Hidden Files**:
   - Make sure `.htaccess` is present in `public_html/asim/` and inside `public_html/asim/db/.htaccess`.
   - In Hostinger File Manager settings (top right gear icon), ensure **Show Hidden Files (dotfiles)** is enabled.

5. **Permissions**:
   - The folder `public_html/asim/` and `public_html/asim/db/` should have default permissions `755` (default on Hostinger).

6. **Open in Browser**:
   - Visit: `https://asim.eztoolbox.xyz`
   - On first visit, the SQLite database `vault_data.sqlite` will be automatically generated inside `public_html/asim/db/` with 0 initial stock!

7. **Start Using**:
   - Log in as **Hadi** (`91199119`) to upload your fresh mails with header: `email,password,recovery email`.
   - Rana Asim can log in (`rana asim` / `rana@123`) to extract available mails, download them, view order history, and submit replacements.
